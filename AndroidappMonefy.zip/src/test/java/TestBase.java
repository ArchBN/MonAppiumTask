import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

public class TestBase {
    //public  static AppiumDriver driver;
    //String projectPath= System.getProperty("user.dir");
    public static AndroidDriver<AndroidElement> driver;
    @BeforeTest
    //desired capabilities are sent from a client to appium server
           public static AndroidDriver<AndroidElement> Android_setup() throws Exception {
            File apkPath = new File("C:\\Users\\nbhat\\Androidapp\\Tests\\APKS");
            File apkName = new File(apkPath, "com.monefy.app.lite_2021-09-27.apk");
            DesiredCapabilities cap = new DesiredCapabilities();

            cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Pixel_2_API_27");
            cap.setCapability(MobileCapabilityType.APP, apkName.getAbsolutePath());
            cap.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");

            driver = new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
            PageFactory.initElements(new AjaxElementLocatorFactory(driver, 10), cap);
            return driver;
        }
    // close a driver after test
    @AfterClass
    public void tearDown()
    {
        if(null!=driver)
        {
            driver.quit();
        }
    }
}
